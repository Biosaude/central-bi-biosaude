# Homologação Biosaúde no Windows 11

## Execução única no computador do operador

Pré-requisitos: PowerShell 7.2+, Node.js 24 LTS, Git, Bun, curl e tar. Use Docker Desktop em modo Linux com Docker Engine 28+. O script verifica as ferramentas e instala o Supabase CLI 2.76.14 a partir do release oficial com SHA-256 fixo. A instalação das ferramentas de sistema, quando faltar alguma, pode ser iniciada por:

```powershell
winget install --id Microsoft.PowerShell --exact
winget install --id OpenJS.NodeJS.LTS --exact
winget install --id Git.Git --exact
winget install --id Oven-sh.Bun --exact
```

Abra um novo terminal. Mantenha os quatro repositórios como subpastas do mesmo diretório e nas branches publicadas. Se for necessário atualizar uma branch, faça `git fetch origin` e avance somente com fast-forward após revisar mudanças locais. O pacote confere os SHAs publicados e monta cópias isoladas com `git archive`. Alterações existentes nos checkouts não entram na homologação.

```powershell
pwsh -NoProfile -File .\Finalizar-Homologacao-Biosaude.ps1 -Repositorios C:\Biosaude -SomenteVerificar
pwsh -NoProfile -File .\Finalizar-Homologacao-Biosaude.ps1 -Repositorios C:\Biosaude
```

O segundo comando prepara as duas instâncias, aplica o conjunto de migrações exigido por cada aplicação, cria as contas sintéticas admin e visitante, limpa privilégios diretos nas relações protegidas conforme os scripts existentes, carrega os fixtures e executa os testes novos contra as instâncias locais. O Comercial utiliza as duas migrações de versões compartilhadas. As três migrações legadas do Comercial pressupõem tabelas oficiais externas e ficam fora do projeto local vazio. A Retenção aplica suas três migrações versionadas. O script usa uma rede Docker por instância, vinculada a `127.0.0.1`. As portas API/PostgreSQL são `55321/55322` e `55421/55422`. A inicialização é idempotente para os mesmos dados sintéticos. Alterações no estado ou em arquivos que o script controla interrompem o uso daquela frente.

O relatório de cada etapa fica em `%LOCALAPPDATA%\Biosaude-Homologacao-Preview\homologacao.log`. As credenciais Supabase geradas são locais, no subdiretório por dashboard, protegidas pela ACL de Windows aplicada ao diretório de estado. Use `admin.biosaude@synthetic.example.com` ou `visitante.biosaude@synthetic.example.com` como usuário de teste Supabase. A credencial de leitura do Comercial é destinada ao backend. As credenciais Entra e Upstash são independentes das contas Supabase.

## Login corporativo com os dados locais

Em um canal autorizado, reúna os valores já cadastrados em um arquivo privado local baseado em `perfil-corporativo.env.example`. Preserve o PEM multiline. Use a mesma origem e o mesmo endpoint publicados da Central. O script fixa essa audiência. A Central precisa reconhecer os IDs e chaves públicas e conceder leitura a contas corporativas de teste. O bypass Vercel é opcional e pertence ao backend.

Para o Entra, confirme que os clientes Web de teste aceitam os redirecionamentos `http://localhost:55331/api/corporate-auth/callback` (Comercial) e `http://localhost:55431/api/corporate-auth/callback` (Retenção). A Microsoft trata a porta de `localhost` de forma especial no cadastro de redirect URI. Num registro compartilhado, evite criar duas entradas que se distinguem apenas por porta. Preserve os callbacks Preview existentes e use a autorização apropriada do administrador Entra.

O Upstash existente permanece. Para executar também o login local, acrescente, somente mediante autorização, os dois padrões de chave de cada origem localhost ao usuário do respectivo dashboard. Preserve passwords, tokens, comandos e padrões Preview existentes. A inclusão é aditiva, sem `reset`:

```powershell
node .\acl-local.mjs
```

Com o perfil preenchido confira os três tokens e inicie os dashboards:

```powershell
pwsh -NoProfile -File .\Finalizar-Homologacao-Biosaude.ps1 -Repositorios C:\Biosaude -PerfilCorporativo "$env:LOCALAPPDATA\Biosaude\perfil-corporativo.env" -ValidarRedis -Iniciar
```

`-ValidarRedis` usa chaves aleatórias e transitórias, testa os comandos permitidos, revogação por exclusão, consumo, expiração, restrição por namespace e comandos negados. Com `-Iniciar` também testa os namespaces localhost. O script encerra os servidores de aplicação iniciados por ele ao receber Ctrl+C. O browser entra nas origens `http://localhost:55331` e `http://localhost:55431`. O caminho de catálogo Preview permanece voltado aos URLs hospedados.

Para validar as três APIs de concessão por máquina, use `perfil-validar-central.env.example` e `contas-teste.env.example` fora do Git. Este teste envia asserções à Central Preview e gera os registros transitórios previstos na tabela de replay.

```powershell
node .\validar-central-preview.mjs "$env:LOCALAPPDATA\Biosaude\perfil-validar-central.env" "$env:LOCALAPPDATA\Biosaude\contas-teste.env" --confirmar-contas-sinteticas
```

Depois, no navegador: por dashboard, valide login Entra, leitura com concessão, URL direta sem sessão, revogação na Central e reconexão. No Comercial, teste leitor e administrador Supabase separadamente. Na Retenção, confira acesso à base atual e histórico, exportação e publicação com administrador sintético. No Limite Preview, teste login Microsoft no Neon Auth, correspondência do `sub` ao par corporativo `tid/oid`, RLS negando o segundo workspace e concessão revogada. Use só contas fictícias/de teste e fixtures sintéticos. MFA e revogação da Central exigem intervenção autorizada real.

## Limite da homologação

O Supabase local liga somente a loopback. Os Previews Vercel do Comercial e da Retenção precisam de dois destinos Supabase hospedados e comprovadamente sintéticos para a validação remota completa. Com os dois slots ocupados pelos projetos atuais, confirme capacidade corporativa isolada já liberada. Se não houver, a evidência local e o teste do backend da Central continuam úteis, mas o aceite remoto dos dois dashboards e a publicação definitiva ficam bloqueados. O projeto pausado permanece intacto. Este fluxo não usa túneis nem bases oficiais para testes.
