// Emite somente regras públicas; não usa credenciais nem abre conexão.
import {createHash} from 'node:crypto';
for(const [user,prefix,port] of [['comercial-preview','comercial',55331],['retencao-preview','retention',55431]]) {
  const hash=createHash('sha256').update('http://localhost:'+port).digest('hex');
  const base=`${prefix}:preview:${hash}:`;
  console.log(`ACL SETUSER ${user} ~${base}login:* ~${base}session:*`);
}
