// Copiado apenas para a pasta local isolada da Retenção.
import express from 'express';
import { resolve } from 'node:path';
import { createApp } from '../server/app.js';
import { readDataset, saveDataset } from '../server/store.js';
import { syntheticDataset } from '../tests/e2e/synthetic-data.js';

const { RETENTION_LOCAL_SUPABASE, RETENTION_PREVIEW_SUPABASE_URL, RETENTION_PREVIEW_ORIGIN } = process.env;
try {
  if (RETENTION_LOCAL_SUPABASE !== '1' || RETENTION_PREVIEW_SUPABASE_URL !== 'http://127.0.0.1:55421' ||
      RETENTION_PREVIEW_ORIGIN !== 'http://localhost:55431' ||
      process.env.NODE_ENV !== 'development' || process.env.VERCEL || process.env.VERCEL_ENV) throw Error();
  if (process.argv[2] === 'seed') {
    const fixture = syntheticDataset();
    const current = await readDataset(false);
    if (!current) await saveDataset(fixture, false, null, process.env.BIOSAUDE_FIXTURE_ADMIN!);
    const loaded = await readDataset(false);
    if (loaded?.fileName !== fixture.fileName || loaded.asOf !== fixture.asOf ||
        JSON.stringify(loaded.records) !== JSON.stringify(fixture.records)) {
      // JSONB can return fields in a different order. Compare normalized values.
      const compare = (value: unknown) => JSON.stringify(value, (_k, v) =>
        v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).sort()) : v);
      if (loaded?.fileName !== fixture.fileName || loaded.asOf !== fixture.asOf ||
          compare(loaded.records) !== compare(fixture.records)) throw Error();
    }
  } else if (process.argv[2] === 'serve') {
    const server = express();
    const api = createApp(false);
    server.disable('x-powered-by');
    server.use((req, res, next) => {
      if (req.headers.host !== 'localhost:55431') return res.sendStatus(403);
      if (req.path === '/api' || req.path.startsWith('/api/')) return api(req, res, next);
      res.set('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' http://127.0.0.1:55421; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'");
      res.set('Cache-Control','no-store');
      next();
    });
    server.use(express.static(resolve('dist')));
    server.get('/{*path}', (_req, res) => res.sendFile(resolve('dist/index.html')));
    server.listen(55431, '127.0.0.1');
  } else {
    throw Error();
  }
} catch {
  console.error('Falha na inicialização ou validação da Retenção sintética.');
  process.exitCode = 1;
}
