// Executado somente na cópia isolada do Comercial por bun.
import assert from 'node:assert/strict';
import { dashboardConfig } from '../src/lib/dashboard/shared.server';
import { previewReaderSettings, readPreview } from '../src/lib/dashboard/preview-reader.server';
const config=dashboardConfig();
assert(config);
assert.equal(config.url,'http://127.0.0.1:55321');
assert.equal(process.env.COMMERCIAL_LOCAL_SUPABASE,'1');
const prev=process.env.VERCEL_ENV;
try {
  process.env.VERCEL_ENV='preview';
  assert.throws(()=>previewReaderSettings(config),/loopback/);
} finally {
  if(prev===undefined) delete process.env.VERCEL_ENV;
  else process.env.VERCEL_ENV=prev;
}
const actual=await readPreview<{manifest:{import:{file_name:string}}}>(config,'manifest');
assert.equal(actual.manifest.import.file_name,'fixture-biosaude-sintetica.xlsx');
const snapshot=await readPreview<{snapshot:{faturamento:{valor:number}[]}}>(config,'snapshot');
assert.equal(snapshot.snapshot.faturamento[0]?.valor,123.45);
process.exit(0); // encerra o pool local depois do teste direcionado
