// Exercita exclusivamente a API do Preview com contas de teste autorizadas.
// As asserções deixam somente os registros transitórios anti-replay previstos no contrato.
import { readFileSync, realpathSync } from 'node:fs';
import { dirname } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createPrivateKey, randomUUID, sign } from 'node:crypto';
import { parseEnv } from 'node:util';

const central='https://central-bi-biosaude-git-feat-commercial-entitl-44f2cd-biosaude1.vercel.app';
const apps=[
 ['Comercial','commercial','movopainelcomercial','painel-comercial-r1','CENTRAL_BI','COMMERCIAL'],
 ['Retenção','retention','biosaude-retention','retencao-faturamento','RETENTION_CENTRAL_BI','RETENTION'],
 ['Limite','global-limit','biosaude-global-limit','limite-global-cliente','GLOBAL_LIMIT_CENTRAL_BI','GLOBAL_LIMIT'],
];
const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
async function main() {
  if(process.argv.length!==5 || process.argv[4]!=='--confirmar-contas-sinteticas')
    throw Error('Uso: node validar-central-preview.mjs perfil.env contas-teste.env --confirmar-contas-sinteticas');
  const load=path=>{
    const file=realpathSync(path);
    if(spawnSync('git',['-C',dirname(file),'rev-parse','--is-inside-work-tree'],{stdio:'ignore'}).status===0)
      throw Error('Os arquivos privados devem ficar fora do Git.');
    return parseEnv(readFileSync(file,'utf8'));
  };
  const credentials=load(process.argv[2]), accounts=load(process.argv[3]);
  if(!uuid.test(accounts.TESTE_ENTRA_TENANT_ID??'')) throw Error('Tenant de teste inválido.');
  const keys=apps.map(([name,path,issuer,slug,prefix,app])=>{
    const yes=accounts[app+'_TESTE_OID_COM_CONCESSAO'], no=accounts[app+'_TESTE_OID_SEM_CONCESSAO'];
    if(!uuid.test(yes??'')||!uuid.test(no??'')||yes.toLowerCase()===no.toLowerCase()) throw Error('Contas de teste inválidas de '+name+'.');
    const key=createPrivateKey(credentials[prefix+'_ASSERTION_PRIVATE_KEY']??'');
    const kid=credentials[prefix+'_ASSERTION_KEY_ID'];
    if(key.asymmetricKeyType!=='ed25519'||!kid) throw Error('Chave Ed25519/ID inválido de '+name+'.');
    return {name,url:central+'/api/internal/'+path+'-entitlement',issuer,slug,key,kid,yes,no,
      bypass:credentials[app+'_CENTRAL_BI_VERCEL_BYPASS_TOKEN']};
  });
  const encode=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
  for(const app of keys) {
    function token(oid,expiry=30){
      const now=Math.floor(Date.now()/1000)+Math.min(0,expiry-30);
      const parts=encode({alg:'EdDSA',typ:'JWT',kid:app.kid})+'.'+encode({
        iss:app.issuer,sub:app.issuer,aud:app.url,iat:now,exp:now+30,jti:randomUUID(),
        tid:accounts.TESTE_ENTRA_TENANT_ID,oid,dashboard:app.slug,permission:'dashboard:read'
      });
      return parts+'.'+sign(null,Buffer.from(parts),app.key).toString('base64url');
    }
    async function expect(tokenValue, status, expected){
      const response=await fetch(app.url,{method:'POST',redirect:'error',signal:AbortSignal.timeout(8000),
        headers:{Authorization:'Bearer '+tokenValue,...(app.bypass&&{'x-vercel-protection-bypass':app.bypass})}});
      const body=await response.json().catch(()=>null);
      if(response.status!==status || !body || Object.keys(expected).some(k=>body[k]!==expected[k]))
        throw Error(`${app.name}: decisão divergente ou proteção Vercel (HTTP ${response.status}).`);
    }
    const reusable=token(app.yes);
    await expect(reusable,200,{allowed:true});
    await expect(reusable,401,{error:'invalid_assertion'});
    await expect(token(app.no),200,{allowed:false});
    await expect(token(app.yes,-90),401,{error:'invalid_assertion'});
    console.log(app.name+': concessão, negação, assinatura, replay e expiração validados.');
  }
}
main().catch(error=>{
  // Network/crypto exceptions can contain input details. Publish only fixed validation diagnostics.
  const message=String(error?.message);
  console.error(/^(Uso:|Os arquivos privados|Tenant de teste|Contas de teste|Chave Ed25519|(?:Comercial|Retenção|Limite): decisão divergente)/.test(message)
    ? message : 'Falha de arquivo, formato criptográfico ou conectividade no Preview.');
  process.exitCode=1;
});
